# Gamma Engine
It mainly contains several interfaces communicating with Partition Server of Vectorbase. The engine can store and index documents which include scalars and vectors. Besides this, it can also support the real time updating of the documents. When searching vectors, numeric scalars can be used to filter. 


 
