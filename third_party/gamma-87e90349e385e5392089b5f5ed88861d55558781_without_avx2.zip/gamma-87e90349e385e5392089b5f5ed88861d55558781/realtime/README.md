# The implementation of real time inverted index
This is a high-performance, concurrent real time inverted index. The details of the implementation please see our paper - [The Design and Implementation of a Real Time Visual Search System On JD E-commerce Platform](https://arxiv.org/abs/1908.07389) 
